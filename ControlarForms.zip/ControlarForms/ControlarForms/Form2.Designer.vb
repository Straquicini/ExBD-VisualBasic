﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Formulario2 = New Label()
        BotaoForm2 = New Button()
        SuspendLayout()
        ' 
        ' Formulario2
        ' 
        Formulario2.AutoSize = True
        Formulario2.Location = New Point(12, 9)
        Formulario2.Name = "Formulario2"
        Formulario2.Size = New Size(81, 15)
        Formulario2.TabIndex = 0
        Formulario2.Text = "Formulário #2"
        ' 
        ' BotaoForm2
        ' 
        BotaoForm2.Location = New Point(392, 239)
        BotaoForm2.Name = "BotaoForm2"
        BotaoForm2.Size = New Size(132, 32)
        BotaoForm2.TabIndex = 1
        BotaoForm2.Text = "Fechar Form#2"
        BotaoForm2.UseVisualStyleBackColor = True
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(536, 283)
        ControlBox = False
        Controls.Add(BotaoForm2)
        Controls.Add(Formulario2)
        Name = "Form2"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form2"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Formulario2 As Label
    Friend WithEvents BotaoForm2 As Button
End Class
