﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Formalario1 = New Label()
        BotaoAbrirForm = New Button()
        BotaoFechar = New Button()
        SuspendLayout()
        ' 
        ' Formalario1
        ' 
        Formalario1.AutoSize = True
        Formalario1.Location = New Point(12, 9)
        Formalario1.Name = "Formalario1"
        Formalario1.Size = New Size(115, 15)
        Formalario1.TabIndex = 0
        Formalario1.Text = "Formulário inicial #1"
        ' 
        ' BotaoAbrirForm
        ' 
        BotaoAbrirForm.Location = New Point(351, 214)
        BotaoAbrirForm.Name = "BotaoAbrirForm"
        BotaoAbrirForm.Size = New Size(140, 39)
        BotaoAbrirForm.TabIndex = 1
        BotaoAbrirForm.Text = "Abrir Form#2"
        BotaoAbrirForm.UseVisualStyleBackColor = True
        ' 
        ' BotaoFechar
        ' 
        BotaoFechar.Location = New Point(12, 193)
        BotaoFechar.Name = "BotaoFechar"
        BotaoFechar.Size = New Size(134, 60)
        BotaoFechar.TabIndex = 2
        BotaoFechar.Text = "Fechar Aplicação"
        BotaoFechar.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(503, 265)
        Controls.Add(BotaoFechar)
        Controls.Add(BotaoAbrirForm)
        Controls.Add(Formalario1)
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Formalario1 As Label
    Friend WithEvents BotaoAbrirForm As Button
    Friend WithEvents BotaoFechar As Button

End Class
