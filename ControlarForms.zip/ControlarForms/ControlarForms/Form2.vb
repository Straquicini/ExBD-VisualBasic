﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles BotaoForm2.Click
        Form1.frm2 = Nothing
        Form1.Show()
        Me.Close()
    End Sub
End Class