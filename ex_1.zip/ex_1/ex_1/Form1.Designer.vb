﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        BotCalcular = New Button()
        ValorAltura = New TextBox()
        ValorPeso = New TextBox()
        Altura = New Label()
        Peso = New Label()
        Resultado = New TextBox()
        ResultadoTexto = New Label()
        SuspendLayout()
        ' 
        ' BotCalcular
        ' 
        BotCalcular.Location = New Point(89, 184)
        BotCalcular.Name = "BotCalcular"
        BotCalcular.Size = New Size(100, 23)
        BotCalcular.TabIndex = 0
        BotCalcular.Text = "Calcular"
        BotCalcular.UseVisualStyleBackColor = True
        ' 
        ' ValorAltura
        ' 
        ValorAltura.Location = New Point(89, 64)
        ValorAltura.Name = "ValorAltura"
        ValorAltura.Size = New Size(100, 23)
        ValorAltura.TabIndex = 1
        ' 
        ' ValorPeso
        ' 
        ValorPeso.Location = New Point(89, 106)
        ValorPeso.Name = "ValorPeso"
        ValorPeso.Size = New Size(100, 23)
        ValorPeso.TabIndex = 2
        ' 
        ' Altura
        ' 
        Altura.AutoSize = True
        Altura.Location = New Point(27, 67)
        Altura.Name = "Altura"
        Altura.Size = New Size(39, 15)
        Altura.TabIndex = 3
        Altura.Text = "Altura"
        ' 
        ' Peso
        ' 
        Peso.AutoSize = True
        Peso.Location = New Point(27, 109)
        Peso.Name = "Peso"
        Peso.Size = New Size(32, 15)
        Peso.TabIndex = 4
        Peso.Text = "Peso"
        ' 
        ' Resultado
        ' 
        Resultado.Location = New Point(89, 146)
        Resultado.Name = "Resultado"
        Resultado.Size = New Size(100, 23)
        Resultado.TabIndex = 5
        ' 
        ' ResultadoTexto
        ' 
        ResultadoTexto.AutoSize = True
        ResultadoTexto.Location = New Point(27, 149)
        ResultadoTexto.Name = "ResultadoTexto"
        ResultadoTexto.Size = New Size(59, 15)
        ResultadoTexto.TabIndex = 6
        ResultadoTexto.Text = "Resultado"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.Highlight
        ClientSize = New Size(284, 261)
        Controls.Add(ResultadoTexto)
        Controls.Add(Resultado)
        Controls.Add(Peso)
        Controls.Add(Altura)
        Controls.Add(ValorPeso)
        Controls.Add(ValorAltura)
        Controls.Add(BotCalcular)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form1"
        Text = "Projeto #1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents BotCalcular As Button
    Friend WithEvents ValorAltura As TextBox
    Friend WithEvents ValorPeso As TextBox
    Friend WithEvents Altura As Label
    Friend WithEvents Peso As Label
    Friend WithEvents Resultado As TextBox
    Friend WithEvents ResultadoTexto As Label

End Class
